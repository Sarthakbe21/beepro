import React from 'react'

const Teacher = () => {
  return (
    <div>Teacher</div>
  )
}

export default Teacher